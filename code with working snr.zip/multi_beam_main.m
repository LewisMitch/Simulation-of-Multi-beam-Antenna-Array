close all; clc;

% Parameters
f = 14e9;
lambda = 3e8 / f;
k = 2 * pi / lambda;
M = 4; N = 4;
dx = lambda / 2;
dz = lambda / 2;
P_t = 10;
G_t = 35;
G_r = 25;
B = 100e6;
T = 290;

% --- Angular Resolution Calculation (User's Equation) ---
res_phi_deg = (2 / M) * (180 / pi);
res_theta_deg = (2 / N) * (180 / pi);

fprintf('Estimated Angular Resolution:\n');
fprintf('   Phi (Azimuth) Resolution ≈ %.2f°\n', res_phi_deg);
fprintf('   Theta (Elevation) Resolution ≈ %.2f°\n\n', res_theta_deg);

% Simulation Settings
tleFile = 'celestrak_TLE_DATA.txt';
simulationTime = 200;
epoch_time = 0;

totalSatellites = 20;
numBeams = 3;
earthRadius = 6371;

% Create Figure 1: Beamforming Visualization
figure(1);
set(gcf, 'Position', [100, 300, 700, 600]);
title('Multi-Beam Steering');
xlabel('X'); ylabel('Y'); zlabel('Z');

% Create Figure 2: Satellite Orbits
figure(2);
set(gcf, 'Position', [850, 300, 700, 600]);
hold on;
set(gca, 'Color', 'w');
set(gcf, 'Color', 'w');
[x_sphere, y_sphere, z_sphere] = sphere(50);
surf((x_sphere * earthRadius) - earthRadius, y_sphere * earthRadius, z_sphere * earthRadius, 'EdgeColor', 'none', 'FaceAlpha', 0.3);
title('Satellite Orbits (All Satellites + Tracked)');
axis equal;
view(45, 30);
grid off;
xticklabels([]); yticklabels([]); zticklabels([]);
set(gca, 'XColor', 'none', 'YColor', 'none', 'ZColor', 'none');

satellitePlots = gobjects(1, totalSatellites);
satelliteMarkers = gobjects(1, totalSatellites);
satelliteLabels = gobjects(1, totalSatellites);

plot3(0, 0, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
text(0, 0, 0, '  Ground Station', 'FontSize', 10, 'Color', 'r', 'FontWeight', 'bold');

for t = 1:simulationTime
    [phiMaxArray, thetaMaxArray, dist_km, SNR, sat_positions, sat_labels] = ...
        process_TLE(tleFile, totalSatellites, epoch_time, f, P_t, G_t, G_r, B, T, M, N);
    dist_m = dist_km * 1e3;
    sat_positions(1, :, :) = sat_positions(1, :, :) - earthRadius;

    validSatellites = find(~isnan(phiMaxArray) & ~isnan(thetaMaxArray) & ...
                           phiMaxArray >= -120 & phiMaxArray <= 120 & ...
                           thetaMaxArray >= -120 & thetaMaxArray <= 120);

    if ~isempty(validSatellites)
        [~, sortedIndex] = sort(SNR(validSatellites), 'descend');
        bestSatellites = validSatellites(sortedIndex(1:min(numBeams, length(validSatellites))));
    else
        bestSatellites = [];
    end

    phi = linspace(0, pi, 500);
    theta = linspace(0, pi, 500);
    AF_total = zeros(length(phi), length(theta));

    for b = 1:length(bestSatellites)
        beam_phi = phiMaxArray(bestSatellites(b));
        beam_theta = thetaMaxArray(bestSatellites(b));

        fprintf('Time %ds - Satellite %d\n', t, bestSatellites(b));
        fprintf('   Original Beam Angles: Phi = %.2f°, Theta = %.2f°\n', beam_phi, beam_theta);

        clipped_phi = round(beam_phi / res_phi_deg) * res_phi_deg;
        clipped_theta = round(beam_theta / res_theta_deg) * res_theta_deg;

        fprintf('   Clipped Beam Angles:  Phi = %.2f°, Theta = %.2f°\n', clipped_phi, clipped_theta);

        gainLoss = cosd(beam_phi - clipped_phi) * cosd(beam_theta - clipped_theta);
        gainLoss = max(gainLoss, 0.01);

        SNR_dB = SNR(bestSatellites(b));
        beamLoss_dB = 10 * log10(gainLoss);
        SNR_dB_adjusted = SNR_dB + beamLoss_dB;

        fprintf('   Original SNR: %.2f dB | Adjusted SNR: %.2f dB\n\n', SNR_dB, SNR_dB_adjusted);

        alphaX = -k * dx * cosd(clipped_phi);
        alphaZ = -k * dz * sind(clipped_theta);

        AFx = sum(exp(1i * (0:M-1)' * (k * dx * cos(phi) + alphaX)), 1);
        AFz = sum(exp(1i * (0:N-1)' * (k * dz * cos(theta) + alphaZ)), 1);
        AF_beam = (AFx.' * AFz);
        AF_total = AF_total + abs(AF_beam);
    end

    figure(1);
    clf;
    [theta_grid, phi_grid] = meshgrid(theta, phi);
    x = abs(AF_total) .* sin(theta_grid) .* cos(phi_grid);
    y = abs(AF_total) .* sin(theta_grid) .* sin(phi_grid);
    z = abs(AF_total) .* cos(theta_grid);

    mesh(x, y, z, abs(AF_total));
    axis equal;
    xlabel('X'); ylabel('Y'); zlabel('Z');
    title(['Time: ', num2str(t), 's | Beam Steering']);
    colorbar;
    axis([-1000 1000 -1000 1000 -1000 1000])
    view(145, 20);

    figure(2);
    hold on;
    for b = 1:totalSatellites
        sat_x = squeeze(sat_positions(1, b, :));
        sat_y = squeeze(sat_positions(2, b, :));
        sat_z = squeeze(sat_positions(3, b, :));

        if ishandle(satellitePlots(b))
            set(satellitePlots(b), 'XData', sat_x, 'YData', sat_y, 'ZData', sat_z);
        else
            satellitePlots(b) = plot3(sat_x, sat_y, sat_z, '--', 'LineWidth', 1);
        end

        current_x = sat_x(mod(t, 360) + 1);
        current_y = sat_y(mod(t, 360) + 1);
        current_z = sat_z(mod(t, 360) + 1);

        if ismember(b, bestSatellites)
            markerColor = 'g';
        else
            markerColor = 'y';
        end

        if ishandle(satelliteMarkers(b))
            set(satelliteMarkers(b), 'XData', current_x, 'YData', current_y, 'ZData', current_z, 'MarkerFaceColor', markerColor);
        else
            satelliteMarkers(b) = scatter3(current_x, current_y, current_z, 100, markerColor, 'filled');
        end
    end

    view(mod(t * 0.5, 360), 30);
    epoch_time = epoch_time + 1;
    pause(0.01);
end