
function [phiMaxArray, thetaMaxArray, dist_km, SNR, sat_positions, sat_labels] = ...
    process_TLE(tleFile, numBeams, epoch_time, f, P_t, G_t, G_r, B, T, M, N)

    % Read the TLE file
    fid = fopen(tleFile, 'r');
    tle_lines = textscan(fid, '%s', 'Delimiter', '\n');
    fclose(fid);
    tle_lines = tle_lines{1};

    % Constants
    mu = 398600; % Earth's gravitational parameter (km^3/s^2)
    Re = 6371;   % Earth radius (km)
    k_B = 1.38e-23;
    lambda = 3e8 / f;

    % Angular resolution
    res_phi_deg = (2 / M) * (180 / pi);
    res_theta_deg = (2 / N) * (180 / pi);

    % Initialize arrays
    phiMaxArray = zeros(1, numBeams);
    thetaMaxArray = zeros(1, numBeams);
    dist_km = zeros(1, numBeams);
    sat_positions = zeros(3, numBeams, 360);
    sat_labels = strings(1, numBeams);
    SNR = zeros(1, numBeams);

    for i = 1:numBeams
        sat_labels(i) = tle_lines{3*i - 2};
        line2 = tle_lines{3*i};

        L3 = sscanf(line2, '%d%6d%f%f%f%f%f%f%f', [1,8]);

        inc = L3(1,3);  
        RAAN = L3(1,4); 
        e = L3(1,5) / 1e7;
        w = L3(1,6);
        M_anom = L3(1,7) + epoch_time * L3(1,8) * 360; 
        n = L3(1,8);

        a = (mu / (n * 2 * pi / (24 * 3600))^2)^(1/3);

        for j = 1:360
            E = j;
            nu = 2 * atand(sqrt((1+e)/(1-e)) * tand(E/2));
            r = a * (1 - e^2) / (1 + e * cosd(nu));

            r_pqw = [r * cosd(nu); r * sind(nu); 0];
            R3_W = [cosd(w), sind(w), 0; -sind(w), cosd(w), 0; 0, 0, 1];
            R1_i = [1, 0, 0; 0, cosd(inc), sind(inc); 0, -sind(inc), cosd(inc)];
            R3_RAAN = [cosd(RAAN), sind(RAAN), 0; -sind(RAAN), cosd(RAAN), 0; 0, 0, 1];
            r_eci = R3_RAAN * R1_i * R3_W * r_pqw;

            sat_positions(:, i, j) = r_eci;
        end

        % Compute satellite position
        vec_x = sat_positions(1, i, mod(epoch_time, 360) + 1) - Re;
        vec_y = sat_positions(2, i, mod(epoch_time, 360) + 1);
        vec_z = sat_positions(3, i, mod(epoch_time, 360) + 1);

        phiMaxArray(i) = atan2d(vec_y, vec_x);
        thetaMaxArray(i) = asind(vec_z / norm([vec_x, vec_y, vec_z]));
        dist_km(i) = norm([vec_x; vec_y; vec_z]);
        dist_m = dist_km(i) * 1e3;

        % SNR Calculation
        P_r_dB = 10*log10(P_t) + G_t + G_r + 20*log10(lambda / (4 * pi * dist_m));
        P_n_dB = 10*log10(k_B * T * B);
        SNR_raw_dB = P_r_dB - P_n_dB;

        % Resolution clipping
        clipped_phi = round(phiMaxArray(i) / res_phi_deg) * res_phi_deg;
        clipped_theta = round(thetaMaxArray(i) / res_theta_deg) * res_theta_deg;

        delta_phi = deg2rad(phiMaxArray(i) - clipped_phi);
        delta_theta = deg2rad(thetaMaxArray(i) - clipped_theta);
        gainLoss = (sinc(delta_phi / deg2rad(res_phi_deg)))^2 * ...
                   (sinc(delta_theta / deg2rad(res_theta_deg)))^2;
        gainLoss = max(gainLoss, 0.01);

        beamLoss_dB = 10 * log10(gainLoss);
        SNR(i) = SNR_raw_dB + beamLoss_dB;

        if thetaMaxArray(i) < 0 || thetaMaxArray(i) > 180
            phiMaxArray(i) = NaN;
            thetaMaxArray(i) = NaN;
        end
    end
end
